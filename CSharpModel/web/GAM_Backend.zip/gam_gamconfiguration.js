/*
               File: GAM_GAMConfiguration
        Description: GAM_GAMConfiguration
             Author: GeneXus .NET Framework Generator version 17_0_9-159740
       Generated on: 4/26/2022 0:33:15.14
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_gamconfiguration', false, function () {
   this.ServerClass =  "gam_gamconfiguration" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_gamconfiguration.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.Validv_Enabletracing=function()
   {
      return this.validCliEvt("Validv_Enabletracing", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vENABLETRACING");
         this.AnyError  = 0;
         if ( ! ( ( this.AV7EnableTracing == 0 ) || ( this.AV7EnableTracing == 1 ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Enable tracing"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e122y2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e142y2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,12,13,16,17,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55];
   this.GXLastCtrlId =55;
   this.TABEMAILContainer = gx.uc.getNew(this, 14, 0, "gx.ui.controls.Tab", "TABEMAILContainer", "Tabemail", "TABEMAIL");
   var TABEMAILContainer = this.TABEMAILContainer;
   TABEMAILContainer.setProp("Enabled", "Enabled", true, "boolean");
   TABEMAILContainer.setProp("ActivePage", "Activepage", '', "int");
   TABEMAILContainer.setProp("ActivePageControlName", "Activepagecontrolname", "", "char");
   TABEMAILContainer.setProp("PageCount", "Pagecount", 1, "num");
   TABEMAILContainer.setProp("Class", "Class", "Tab", "str");
   TABEMAILContainer.setProp("HistoryManagement", "Historymanagement", false, "bool");
   TABEMAILContainer.setProp("Visible", "Visible", true, "bool");
   TABEMAILContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(TABEMAILContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"GENERAL_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"TABPAGE1TABLE",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMDATABASEVERSION",gxz:"ZV12GAMDatabaseVersion",gxold:"OV12GAMDatabaseVersion",gxvar:"AV12GAMDatabaseVersion",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12GAMDatabaseVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12GAMDatabaseVersion=Value},v2c:function(){gx.fn.setControlValue("vGAMDATABASEVERSION",gx.O.AV12GAMDatabaseVersion,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12GAMDatabaseVersion=this.val()},val:function(){return gx.fn.getControlValue("vGAMDATABASEVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id:29 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMAPIVERSION",gxz:"ZV11GAMAPIVersion",gxold:"OV11GAMAPIVersion",gxvar:"AV11GAMAPIVersion",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11GAMAPIVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11GAMAPIVersion=Value},v2c:function(){gx.fn.setControlValue("vGAMAPIVERSION",gx.O.AV11GAMAPIVersion,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11GAMAPIVersion=this.val()},val:function(){return gx.fn.getControlValue("vGAMAPIVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 29 , function() {
   });
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"TBLDEFAULTREPO",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id:37 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTREPOSITORY",gxz:"ZV5DefaultRepository",gxold:"OV5DefaultRepository",gxvar:"AV5DefaultRepository",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV5DefaultRepository=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5DefaultRepository=Value},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTREPOSITORY",gx.O.AV5DefaultRepository);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5DefaultRepository=this.val()},val:function(){return gx.fn.getControlValue("vDEFAULTREPOSITORY")},nac:gx.falseFn};
   this.declareDomainHdlr( 37 , function() {
   });
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"TBLCUSTOMEMAILREGEXP",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"svchar",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILREGULAREXPRESSION",gxz:"ZV6EmailRegularExpression",gxold:"OV6EmailRegularExpression",gxvar:"AV6EmailRegularExpression",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV6EmailRegularExpression=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6EmailRegularExpression=Value},v2c:function(){gx.fn.setControlValue("vEMAILREGULAREXPRESSION",gx.O.AV6EmailRegularExpression,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV6EmailRegularExpression=this.val()},val:function(){return gx.fn.getControlValue("vEMAILREGULAREXPRESSION")},nac:gx.falseFn};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id:50 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:this.Validv_Enabletracing,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENABLETRACING",gxz:"ZV7EnableTracing",gxold:"OV7EnableTracing",gxvar:"AV7EnableTracing",ucs:[],op:[50],ip:[50],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV7EnableTracing=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV7EnableTracing=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vENABLETRACING",gx.O.AV7EnableTracing);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV7EnableTracing=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vENABLETRACING",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 50 , function() {
   });
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"CONFIRM",grid:0,evt:"e122y2_client",std:"ENTER"};
   this.AV12GAMDatabaseVersion = "" ;
   this.ZV12GAMDatabaseVersion = "" ;
   this.OV12GAMDatabaseVersion = "" ;
   this.AV11GAMAPIVersion = "" ;
   this.ZV11GAMAPIVersion = "" ;
   this.OV11GAMAPIVersion = "" ;
   this.AV5DefaultRepository = "" ;
   this.ZV5DefaultRepository = "" ;
   this.OV5DefaultRepository = "" ;
   this.AV6EmailRegularExpression = "" ;
   this.ZV6EmailRegularExpression = "" ;
   this.OV6EmailRegularExpression = "" ;
   this.AV7EnableTracing = 0 ;
   this.ZV7EnableTracing = 0 ;
   this.OV7EnableTracing = 0 ;
   this.AV12GAMDatabaseVersion = "" ;
   this.AV11GAMAPIVersion = "" ;
   this.AV5DefaultRepository = "" ;
   this.AV6EmailRegularExpression = "" ;
   this.AV7EnableTracing = 0 ;
   this.Events = {"e122y2_client": ["ENTER", true] ,"e142y2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV12GAMDatabaseVersion',fld:'vGAMDATABASEVERSION',pic:''}],[]];
   this.EvtParms["ENTER"] = [[{ctrl:'vENABLETRACING'},{av:'AV7EnableTracing',fld:'vENABLETRACING',pic:'ZZZ9'},{av:'AV6EmailRegularExpression',fld:'vEMAILREGULAREXPRESSION',pic:''},{ctrl:'vDEFAULTREPOSITORY'},{av:'AV5DefaultRepository',fld:'vDEFAULTREPOSITORY',pic:''}],[]];
   this.EvtParms["VALIDV_ENABLETRACING"] = [[],[]];
   this.EnterCtrl = ["CONFIRM"];
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_gamconfiguration);});
