/*
               File: GAM_WWAuthTypes
        Description: Authentication Types
             Author: GeneXus .NET Framework Generator version 17_0_9-159740
       Generated on: 4/26/2022 0:31:5.84
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwauthtypes', false, function () {
   this.ServerClass =  "gam_wwauthtypes" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwauthtypes.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.Validv_Typeid=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(23);
      return this.validCliEvt("Validv_Typeid", 23, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vTYPEID");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV13TypeId , "AppleID" ) == 0 || gx.text.compare( this.AV13TypeId , "Custom" ) == 0 || gx.text.compare( this.AV13TypeId , "ExternalWebService" ) == 0 || gx.text.compare( this.AV13TypeId , "Facebook" ) == 0 || gx.text.compare( this.AV13TypeId , "GAMLocal" ) == 0 || gx.text.compare( this.AV13TypeId , "GAMRemote" ) == 0 || gx.text.compare( this.AV13TypeId , "GAMRemoteRest" ) == 0 || gx.text.compare( this.AV13TypeId , "Google" ) == 0 || gx.text.compare( this.AV13TypeId , "Oauth20" ) == 0 || gx.text.compare( this.AV13TypeId , "OTP" ) == 0 || gx.text.compare( this.AV13TypeId , "Saml20" ) == 0 || gx.text.compare( this.AV13TypeId , "Twitter" ) == 0 || gx.text.compare( this.AV13TypeId , "WeChat" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Type Id"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e110e2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e130e2_client=function()
   {
      /* Name_Click Routine */
      return this.executeServerEvent("VNAME.CLICK", true, arguments[0], false, false);
   };
   this.e140e2_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e150e2_client=function()
   {
      /* Btntestws_Click Routine */
      return this.executeServerEvent("VBTNTESTWS.CLICK", true, arguments[0], false, false);
   };
   this.e160e2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e170e2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e180e2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,24,25,26,27,28];
   this.GXLastCtrlId =28;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",23,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwauthtypes",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",24,"vNAME",gx.getMessage( "Name"),"","Name","char",0,"px",60,60,"left","e130e2_client",[],"Name","Name",true,0,false,false,"Attribute TextLikeLink SmallLink",1,"WWColumn");
   GridwwContainer.addComboBox("Typeid",25,"vTYPEID",gx.getMessage( "Authentication  Types"),"TypeId","char",null,0,true,false,0,"px","WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",26,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e140e2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btntestws",27,"vBTNTESTWS","","","BtnTestWS","char",0,"px",20,20,"left","e150e2_client",[],"Btntestws","BtnTestWS",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndlt",28,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"left","e160e2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE2",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"ADDNEW",grid:0,evt:"e110e2_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILNAME",gxz:"ZV10FilName",gxold:"OV10FilName",gxvar:"AV10FilName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10FilName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10FilName=Value},v2c:function(){gx.fn.setControlValue("vFILNAME",gx.O.AV10FilName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10FilName=this.val()},val:function(){return gx.fn.getControlValue("vFILNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLE1",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV12Name",gxold:"OV12Name",gxvar:"AV12Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV12Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e130e2_client"};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:30,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:this.Validv_Typeid,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTYPEID",gxz:"ZV13TypeId",gxold:"OV13TypeId",gxvar:"AV13TypeId",ucs:[],op:[25],ip:[25],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV13TypeId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13TypeId=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vTYPEID",row || gx.fn.currentGridRowImpl(23),gx.O.AV13TypeId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV13TypeId=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vTYPEID",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",gxz:"ZV8BtnUpd",gxold:"OV8BtnUpd",gxvar:"AV8BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23),gx.O.AV8BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e140e2_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNTESTWS",gxz:"ZV7BtnTestWS",gxold:"OV7BtnTestWS",gxvar:"AV7BtnTestWS",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV7BtnTestWS=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7BtnTestWS=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNTESTWS",row || gx.fn.currentGridRowImpl(23),gx.O.AV7BtnTestWS,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV7BtnTestWS=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNTESTWS",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e150e2_client"};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",gxz:"ZV6BtnDlt",gxold:"OV6BtnDlt",gxvar:"AV6BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(23),gx.O.AV6BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e160e2_client"};
   this.AV10FilName = "" ;
   this.ZV10FilName = "" ;
   this.OV10FilName = "" ;
   this.ZV12Name = "" ;
   this.OV12Name = "" ;
   this.ZV13TypeId = "" ;
   this.OV13TypeId = "" ;
   this.ZV8BtnUpd = "" ;
   this.OV8BtnUpd = "" ;
   this.ZV7BtnTestWS = "" ;
   this.OV7BtnTestWS = "" ;
   this.ZV6BtnDlt = "" ;
   this.OV6BtnDlt = "" ;
   this.AV10FilName = "" ;
   this.AV12Name = "" ;
   this.AV13TypeId = "" ;
   this.AV8BtnUpd = "" ;
   this.AV7BtnTestWS = "" ;
   this.AV6BtnDlt = "" ;
   this.Events = {"e110e2_client": ["'ADDNEW'", true] ,"e130e2_client": ["VNAME.CLICK", true] ,"e140e2_client": ["VBTNUPD.CLICK", true] ,"e150e2_client": ["VBTNTESTWS.CLICK", true] ,"e160e2_client": ["VBTNDLT.CLICK", true] ,"e170e2_client": ["ENTER", true] ,"e180e2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10FilName',fld:'vFILNAME',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV10FilName',fld:'vFILNAME',pic:''}],[{av:'AV8BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV6BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV7BtnTestWS',fld:'vBTNTESTWS',pic:''},{av:'AV12Name',fld:'vNAME',pic:''},{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''},{av:'gx.fn.getCtrlProperty("vBTNTESTWS","Visible")',ctrl:'vBTNTESTWS',prop:'Visible'}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10FilName',fld:'vFILNAME',pic:''}],[]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10FilName',fld:'vFILNAME',pic:''},{av:'AV12Name',fld:'vNAME',pic:''},{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''}],[{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''},{av:'AV12Name',fld:'vNAME',pic:''}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10FilName',fld:'vFILNAME',pic:''},{av:'AV12Name',fld:'vNAME',pic:''},{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''}],[{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''},{av:'AV12Name',fld:'vNAME',pic:''}]];
   this.EvtParms["VBTNTESTWS.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10FilName',fld:'vFILNAME',pic:''},{av:'AV12Name',fld:'vNAME',pic:''},{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''}],[{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''},{av:'AV12Name',fld:'vNAME',pic:''}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10FilName',fld:'vFILNAME',pic:''},{av:'AV12Name',fld:'vNAME',pic:''},{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''}],[{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''},{av:'AV12Name',fld:'vNAME',pic:''}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_TYPEID"] = [[{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''}],[{ctrl:'vTYPEID'},{av:'AV13TypeId',fld:'vTYPEID',pic:''}]];
   GridwwContainer.addRefreshingVar(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[14]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwauthtypes);});
