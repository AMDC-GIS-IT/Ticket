/*
               File: GAM_WWRoles
        Description: Roles
             Author: GeneXus .NET Framework Generator version 17_0_9-159740
       Generated on: 4/26/2022 0:30:52.42
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwroles', false, function () {
   this.ServerClass =  "gam_wwroles" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwroles.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e11061_client=function()
   {
      /* 'AddNew' Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["INS", 0], null, ["Mode","Id"]);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e18062_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["DSP", this.AV12Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e19062_client=function()
   {
      /* Btnupd_Click Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["UPD", this.AV12Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e12061_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV8CurrentPage = gx.num.trunc( 1 ,0) ;
      gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
      gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e13061_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      if ( this.AV8CurrentPage > 1 )
      {
         this.AV8CurrentPage = gx.num.trunc( this.AV8CurrentPage - 1 ,0) ;
      }
      if ( this.AV8CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
         gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      }
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e14061_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      if ( this.AV8CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", true );
         gx.fn.setCtrlProperty("TBPREV","Enabled", true );
      }
      this.AV8CurrentPage = gx.num.trunc( this.AV8CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e17062_client=function()
   {
      /* Btnsaveas_Click Routine */
      return this.executeServerEvent("VBTNSAVEAS.CLICK", true, arguments[0], false, false);
   };
   this.e20062_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e21062_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45];
   this.GXLastCtrlId =45;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",23,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwroles",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",24,"vNAME",gx.getMessage( "Role Name"),"","Name","char",0,"px",254,80,"left","e18062_client",[],"Name","Name",true,0,false,false,"Attribute TextLikeLink SmallLink",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",25,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e19062_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btnsaveas",26,"vBTNSAVEAS","","","BtnSaveAs","char",0,"px",20,20,"left","e17062_client",[],"Btnsaveas","BtnSaveAs",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",27,"vID",gx.getMessage( "Key Numeric Long"),"","Id","int",0,"px",12,12,"right",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLETOP",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"ADDNEW",grid:0,evt:"e11061_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",gxz:"ZV18Search",gxold:"OV18Search",gxvar:"AV18Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV18Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLE1",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV14Name",gxold:"OV14Name",gxvar:"AV14Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV14Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV14Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV14Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e18062_client"};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e19062_client"};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNSAVEAS",gxz:"ZV5BtnSaveAs",gxold:"OV5BtnSaveAs",gxvar:"AV5BtnSaveAs",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnSaveAs=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnSaveAs=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNSAVEAS",row || gx.fn.currentGridRowImpl(23),gx.O.AV5BtnSaveAs,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnSaveAs=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNSAVEAS",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e17062_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV12Id",gxold:"OV12Id",gxvar:"AV12Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV12Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(23),gx.O.AV12Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(23),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"TABLE6",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"TBFIRST", format:0,grid:0,evt:"e12061_client", ctrltype: "textblock"};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"TB2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"TBPREV", format:0,grid:0,evt:"e13061_client", ctrltype: "textblock"};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"TB5", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"TBNEXT", format:0,grid:0,evt:"e14061_client", ctrltype: "textblock"};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",gxz:"ZV8CurrentPage",gxold:"OV8CurrentPage",gxvar:"AV8CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV8CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV8CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   this.AV18Search = "" ;
   this.ZV18Search = "" ;
   this.OV18Search = "" ;
   this.ZV14Name = "" ;
   this.OV14Name = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.ZV5BtnSaveAs = "" ;
   this.OV5BtnSaveAs = "" ;
   this.ZV12Id = 0 ;
   this.OV12Id = 0 ;
   this.AV8CurrentPage = 0 ;
   this.ZV8CurrentPage = 0 ;
   this.OV8CurrentPage = 0 ;
   this.AV18Search = "" ;
   this.AV8CurrentPage = 0 ;
   this.AV14Name = "" ;
   this.AV6BtnUpd = "" ;
   this.AV5BtnSaveAs = "" ;
   this.AV12Id = 0 ;
   this.Events = {"e17062_client": ["VBTNSAVEAS.CLICK", true] ,"e20062_client": ["ENTER", true] ,"e21062_client": ["CANCEL", true] ,"e11061_client": ["'ADDNEW'", false] ,"e18062_client": ["VNAME.CLICK", false] ,"e19062_client": ["VBTNUPD.CLICK", false] ,"e12061_client": ["'FIRST'", false] ,"e13061_client": ["'PREVIOUS'", false] ,"e14061_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV18Search',fld:'vSEARCH',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV18Search',fld:'vSEARCH',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV6BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV5BtnSaveAs',fld:'vBTNSAVEAS',pic:''},{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV14Name',fld:'vNAME',pic:''},{av:'gx.fn.getCtrlProperty("TBNEXT","Class")',ctrl:'TBNEXT',prop:'Class'}]];
   this.EvtParms["'ADDNEW'"] = [[],[]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNSAVEAS.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV18Search',fld:'vSEARCH',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV18Search',fld:'vSEARCH',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV18Search',fld:'vSEARCH',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV18Search',fld:'vSEARCH',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   GridwwContainer.addRefreshingVar(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[45]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[45]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwroles);});
