/*
               File: GAM_RoleSelect
        Description: Select role
             Author: GeneXus .NET Framework Generator version 17_0_9-159740
       Generated on: 4/26/2022 0:32:22.53
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_roleselect', false, function () {
   this.ServerClass =  "gam_roleselect" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_roleselect.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV19RoleIdAux=gx.fn.getIntegerValue("vROLEIDAUX",gx.thousandSeparator) ;
      this.AV21SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
      this.AV15isOK=gx.fn.getControlValue("vISOK") ;
      this.AV18RoleId=gx.fn.getIntegerValue("vROLEID",gx.thousandSeparator) ;
      this.AV19RoleIdAux=gx.fn.getIntegerValue("vROLEIDAUX",gx.thousandSeparator) ;
      this.AV21SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
   };
   this.e111n1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("FILTERSCONTAINER","Class") , "AdvancedContainer" ) == 0 )
      {
         gx.fn.setCtrlProperty("FILTERSCONTAINER","Class", "AdvancedContainer"+" "+"AdvancedContainerVisible" );
         gx.fn.setCtrlProperty("HIDE","Caption", gx.getMessage( "HIDE FILTERS") );
         gx.fn.setCtrlProperty("HIDE","Class", "HideFiltersButton" );
         gx.fn.setCtrlProperty("GRIDCELL","Class", "WWGridCell" );
      }
      else
      {
         gx.fn.setCtrlProperty("FILTERSCONTAINER","Class", "AdvancedContainer" );
         gx.fn.setCtrlProperty("HIDE","Caption", gx.getMessage( "SHOW FILTERS") );
         gx.fn.setCtrlProperty("HIDE","Class", "ShowFiltersButton" );
         gx.fn.setCtrlProperty("GRIDCELL","Class", "WWGridCellExpanded" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'},{ctrl:'HIDE',prop:'Caption'},{ctrl:'HIDE',prop:'Class'},{av:'gx.fn.getCtrlProperty("GRIDCELL","Class")',ctrl:'GRIDCELL',prop:'Class'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e121n1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( 1 ,0) ;
      gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
      gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e131n1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      if ( this.AV7CurrentPage > 1 )
      {
         this.AV7CurrentPage = gx.num.trunc( this.AV7CurrentPage - 1 ,0) ;
      }
      if ( this.AV7CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
         gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      }
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e141n1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      if ( this.AV7CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", true );
         gx.fn.setCtrlProperty("TBPREV","Enabled", true );
      }
      this.AV7CurrentPage = gx.num.trunc( this.AV7CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e151n2_client=function()
   {
      /* 'AddSelected' Routine */
      return this.executeServerEvent("'ADDSELECTED'", false, null, false, false);
   };
   this.e181n2_client=function()
   {
      /* 'AddRole' Routine */
      return this.executeServerEvent("'ADDROLE'", true, arguments[0], false, false);
   };
   this.e191n2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e201n1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,48,49,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72];
   this.GXLastCtrlId =72;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",50,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_roleselect",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addCheckBox("Select",51,"vSELECT",gx.getMessage( "Select"),"","Select","boolean","true","false",null,true,false,0,"px","WWActionColumn");
   GridwwContainer.addSingleLineEdit("Name",52,"vNAME",gx.getMessage( "Role"),"","Name","char",0,"px",254,80,"left",null,[],"Name","Name",true,0,false,false,"Attribute",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Id",53,"vID",gx.getMessage( "Key Numeric Long"),"","Id","int",0,"px",12,12,"right",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   GridwwContainer.addSingleLineEdit("Btnaddrole",54,"vBTNADDROLE","","","BtnAddRole","char",0,"px",20,20,"left","e181n2_client",[],"Btnaddrole","BtnAddRole",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLE5",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"HIDE",grid:0,evt:"e111n1_client"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"TEXTBLOCK2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"TABLE1",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"BACK",grid:0,evt:"e201n1_client"};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"ADDSELECTED",grid:0,evt:"e151n2_client"};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILNAME",gxz:"ZV11FilName",gxold:"OV11FilName",gxvar:"AV11FilName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11FilName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11FilName=Value},v2c:function(){gx.fn.setControlValue("vFILNAME",gx.O.AV11FilName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11FilName=this.val()},val:function(){return gx.fn.getControlValue("vFILNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"CELLFILTERS",grid:0};
   GXValidFnc[27]={ id: 27, fld:"FILTERSCONTAINER",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"TABLE4",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id:37 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILEXTERNALID",gxz:"ZV10FilExternalId",gxold:"OV10FilExternalId",gxvar:"AV10FilExternalId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10FilExternalId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10FilExternalId=Value},v2c:function(){gx.fn.setControlValue("vFILEXTERNALID",gx.O.AV10FilExternalId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10FilExternalId=this.val()},val:function(){return gx.fn.getControlValue("vFILEXTERNALID")},nac:gx.falseFn};
   this.declareDomainHdlr( 37 , function() {
   });
   GXValidFnc[38]={ id: 38, fld:"GRIDCELL",grid:0};
   GXValidFnc[39]={ id: 39, fld:"GRIDTABLE",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id:44 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME1",gxz:"ZV25GXV1",gxold:"OV25GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME1",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME1")},nac:gx.falseFn};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[51]={ id:51 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECT",gxz:"ZV22Select",gxold:"OV22Select",gxvar:"AV22Select",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV22Select=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Select=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vSELECT",row || gx.fn.currentGridRowImpl(50),gx.O.AV22Select,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV22Select=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vSELECT",row || gx.fn.currentGridRowImpl(50))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[52]={ id:52 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV16Name",gxold:"OV16Name",gxvar:"AV16Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV16Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(50),gx.O.AV16Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(50))},nac:gx.falseFn};
   GXValidFnc[53]={ id:53 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV14Id",gxold:"OV14Id",gxvar:"AV14Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV14Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(50),gx.O.AV14Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV14Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(50),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[54]={ id:54 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNADDROLE",gxz:"ZV5BtnAddRole",gxold:"OV5BtnAddRole",gxvar:"AV5BtnAddRole",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnAddRole=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnAddRole=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNADDROLE",row || gx.fn.currentGridRowImpl(50),gx.O.AV5BtnAddRole,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnAddRole=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNADDROLE",row || gx.fn.currentGridRowImpl(50))},nac:gx.falseFn,evt:"e181n2_client"};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"TABLE6",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"TBFIRST", format:0,grid:0,evt:"e121n1_client", ctrltype: "textblock"};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"TB1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"TBPREV", format:0,grid:0,evt:"e131n1_client", ctrltype: "textblock"};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"TB2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"TBNEXT", format:0,grid:0,evt:"e141n1_client", ctrltype: "textblock"};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id:72 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",gxz:"ZV7CurrentPage",gxold:"OV7CurrentPage",gxvar:"AV7CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV7CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV7CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV7CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   this.AV11FilName = "" ;
   this.ZV11FilName = "" ;
   this.OV11FilName = "" ;
   this.AV10FilExternalId = "" ;
   this.ZV10FilExternalId = "" ;
   this.OV10FilExternalId = "" ;
   this.GXV1 = "" ;
   this.ZV25GXV1 = "" ;
   this.OV25GXV1 = "" ;
   this.ZV22Select = false ;
   this.OV22Select = false ;
   this.ZV16Name = "" ;
   this.OV16Name = "" ;
   this.ZV14Id = 0 ;
   this.OV14Id = 0 ;
   this.ZV5BtnAddRole = "" ;
   this.OV5BtnAddRole = "" ;
   this.AV7CurrentPage = 0 ;
   this.ZV7CurrentPage = 0 ;
   this.OV7CurrentPage = 0 ;
   this.AV11FilName = "" ;
   this.AV10FilExternalId = "" ;
   this.GXV1 = "" ;
   this.AV7CurrentPage = 0 ;
   this.AV18RoleId = 0 ;
   this.AV19RoleIdAux = 0 ;
   this.AV22Select = false ;
   this.AV16Name = "" ;
   this.AV14Id = 0 ;
   this.AV5BtnAddRole = "" ;
   this.AV21SearchFilter = "" ;
   this.AV15isOK = false ;
   this.AV13GAMRole = {} ;
   this.Events = {"e151n2_client": ["'ADDSELECTED'", true] ,"e181n2_client": ["'ADDROLE'", true] ,"e191n2_client": ["ENTER", true] ,"e201n1_client": ["CANCEL", true] ,"e111n1_client": ["'HIDE'", false] ,"e121n1_client": ["'FIRST'", false] ,"e131n1_client": ["'PREVIOUS'", false] ,"e141n1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'gx.fn.getCtrlProperty("vBTNADDROLE","Tooltiptext")',ctrl:'vBTNADDROLE',prop:'Tooltiptext'},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV5BtnAddRole',fld:'vBTNADDROLE',pic:''},{av:'AV22Select',fld:'vSELECT',pic:''},{av:'AV14Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV16Name',fld:'vNAME',pic:''},{av:'gx.fn.getCtrlProperty("TBNEXT","Class")',ctrl:'TBNEXT',prop:'Class'}]];
   this.EvtParms["'ADDSELECTED'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'gx.fn.getCtrlProperty("vBTNADDROLE","Tooltiptext")',ctrl:'vBTNADDROLE',prop:'Tooltiptext'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV22Select',fld:'vSELECT',grid:50,pic:''},{av:'nRC_GXsfl_50',ctrl:'GRIDWW',grid:50,prop:'GridRC',grid:50},{av:'AV14Id',fld:'vID',grid:50,pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV15isOK',fld:'vISOK',pic:''}],[{av:'AV15isOK',fld:'vISOK',pic:''}]];
   this.EvtParms["'ADDROLE'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'gx.fn.getCtrlProperty("vBTNADDROLE","Tooltiptext")',ctrl:'vBTNADDROLE',prop:'Tooltiptext'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV14Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{av:'AV15isOK',fld:'vISOK',pic:''}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'},{ctrl:'HIDE',prop:'Caption'},{ctrl:'HIDE',prop:'Class'},{av:'gx.fn.getCtrlProperty("GRIDCELL","Class")',ctrl:'GRIDCELL',prop:'Class'}]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'gx.fn.getCtrlProperty("vBTNADDROLE","Tooltiptext")',ctrl:'vBTNADDROLE',prop:'Tooltiptext'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'gx.fn.getCtrlProperty("vBTNADDROLE","Tooltiptext")',ctrl:'vBTNADDROLE',prop:'Tooltiptext'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'gx.fn.getCtrlProperty("vBTNADDROLE","Tooltiptext")',ctrl:'vBTNADDROLE',prop:'Tooltiptext'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV11FilName',fld:'vFILNAME',pic:''},{av:'AV21SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV19RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV21SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV15isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV18RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV19RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV21SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV19RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV21SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   GridwwContainer.addRefreshingVar({rfrVar:"AV5BtnAddRole", rfrProp:"Tooltiptext", gxAttId:"Btnaddrole"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV19RoleIdAux"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[24]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV21SearchFilter"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[37]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[72]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV5BtnAddRole", rfrProp:"Tooltiptext", gxAttId:"Btnaddrole"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV19RoleIdAux"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[24]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV21SearchFilter"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[37]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[72]);
   this.addBCProperty("Gamrole", ["Name"], this.GXValidFnc[44], "AV13GAMRole");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_roleselect);});
