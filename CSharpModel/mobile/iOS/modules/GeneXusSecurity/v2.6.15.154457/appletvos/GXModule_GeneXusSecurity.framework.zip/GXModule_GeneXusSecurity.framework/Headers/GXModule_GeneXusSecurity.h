//
//  GXModule_GeneXusSecurity.h
//  GXModule_GeneXusSecurity
//

#import <UIKit/UIKit.h>

//! Project version number for GXModule_GeneXusSecurity.
FOUNDATION_EXPORT double GXModule_GeneXusSecurityVersionNumber;

//! Project version string for GXModule_GeneXusSecurity.
FOUNDATION_EXPORT const unsigned char GXModule_GeneXusSecurityVersionString[];

#import <GXModule_GeneXusSecurity/GXGlobalImports.h>

#import <GXModule_GeneXusSecurity/GXExternalObjectBase+GXEOProtocol_GXEOGAMUserData.h>

