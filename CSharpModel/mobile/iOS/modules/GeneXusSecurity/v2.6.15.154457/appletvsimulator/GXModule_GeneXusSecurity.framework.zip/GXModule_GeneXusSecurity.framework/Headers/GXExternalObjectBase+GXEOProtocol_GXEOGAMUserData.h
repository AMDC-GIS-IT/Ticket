@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@class genexussecurity_SdtGAMUser;

@protocol GXEOProtocol_GXEOGAMUserData <NSObject>

- (instancetype)init;

@property(nonatomic, readwrite) NSString * GUID NS_SWIFT_NAME(GUID);
@property(nonatomic, readwrite) NSString * nameSpace NS_SWIFT_NAME(nameSpace);
@property(nonatomic, readwrite) NSString * authenticationtypename NS_SWIFT_NAME(authenticationtypename);
@property(nonatomic, readwrite) NSString * name NS_SWIFT_NAME(name);
@property(nonatomic, readwrite) NSString * login NS_SWIFT_NAME(login);
@property(nonatomic, readwrite) NSString * email NS_SWIFT_NAME(email);
@property(nonatomic, readwrite) NSString * externalid NS_SWIFT_NAME(externalid);
@property(nonatomic, readwrite) NSString * password NS_SWIFT_NAME(password);
@property(nonatomic, readwrite) NSString * firstname NS_SWIFT_NAME(firstname);
@property(nonatomic, readwrite) NSString * lastname NS_SWIFT_NAME(lastname);
@property(nonatomic, readwrite) NSDate * birthday NS_SWIFT_NAME(birthday);
@property(nonatomic, readwrite) NSString * gender NS_SWIFT_NAME(gender);
@property(nonatomic, readwrite) NSString * urlimage NS_SWIFT_NAME(urlimage);
@property(nonatomic, readwrite) NSString * urlprofile NS_SWIFT_NAME(urlprofile);
@property(nonatomic, readwrite) NSString * phone NS_SWIFT_NAME(phone);
@property(nonatomic, readwrite) NSString * address NS_SWIFT_NAME(address);
@property(nonatomic, readwrite) NSString * address2 NS_SWIFT_NAME(address2);
@property(nonatomic, readwrite) NSString * city NS_SWIFT_NAME(city);
@property(nonatomic, readwrite) NSString * state NS_SWIFT_NAME(state);
@property(nonatomic, readwrite) NSString * postcode NS_SWIFT_NAME(postcode);
@property(nonatomic, readwrite) NSString * language NS_SWIFT_NAME(language);
@property(nonatomic, readwrite) NSString * timezone NS_SWIFT_NAME(timezone);
@property(nonatomic, readwrite) BOOL dontreceiveinformation NS_SWIFT_NAME(dontreceiveinformation);
@property(nonatomic, readwrite) BOOL isblocked NS_SWIFT_NAME(isblocked);
@property(nonatomic, readwrite) NSDate * lastblockeddate NS_SWIFT_NAME(lastblockeddate);
@property(nonatomic, readwrite) BOOL isactive NS_SWIFT_NAME(isactive);
@property(nonatomic, readwrite) NSDate * activationdate NS_SWIFT_NAME(activationdate);
@property(nonatomic, readwrite) BOOL cannotchangepassword NS_SWIFT_NAME(cannotchangepassword);
@property(nonatomic, readwrite) BOOL mustchangepassword NS_SWIFT_NAME(mustchangepassword);
@property(nonatomic, readwrite) BOOL passwordneverexpires NS_SWIFT_NAME(passwordneverexpires);
@property(nonatomic, readwrite) NSDate * datelastchangepassword NS_SWIFT_NAME(datelastchangepassword);
@property(nonatomic, readwrite) NSInteger securitypolicyid NS_SWIFT_NAME(securitypolicyid);
@property(nonatomic, readwrite) int64_t defaultroleid NS_SWIFT_NAME(defaultroleid);
@property(nonatomic, readwrite) BOOL enabletwofactorauthentication NS_SWIFT_NAME(enabletwofactorauthentication);
@property(nonatomic, readwrite) NSInteger otpnumberlocked NS_SWIFT_NAME(otpnumberlocked);
@property(nonatomic, readwrite) NSDate * otplastlockeddate NS_SWIFT_NAME(otplastlockeddate);
@property(nonatomic, readwrite) NSInteger otpdailynumbercodes NS_SWIFT_NAME(otpdailynumbercodes);
@property(nonatomic, readwrite) NSDate * otplastdaterequestcode NS_SWIFT_NAME(otplastdaterequestcode);
@property(nonatomic, readwrite) NSInteger otpfailedattempts NS_SWIFT_NAME(otpfailedattempts);
@property(nonatomic, readwrite) NSInteger failedloginattempts NS_SWIFT_NAME(failedloginattempts);
@property(nonatomic, readwrite) NSDate * lastfailedloginattempt NS_SWIFT_NAME(lastfailedloginattempt);
@property(nonatomic, readwrite) NSDate * datelastauthentication NS_SWIFT_NAME(datelastauthentication);
@property(nonatomic, readwrite) BOOL isenabledinrepository NS_SWIFT_NAME(isenabledinrepository);
@property(nonatomic, readwrite) BOOL isdeleted NS_SWIFT_NAME(isdeleted);
@property(nonatomic, readwrite) BOOL isautoregistereduser NS_SWIFT_NAME(isautoregistereduser);
@property(nonatomic, readwrite) NSDate * datecreated NS_SWIFT_NAME(datecreated);
@property(nonatomic, readwrite) NSString * usercreated NS_SWIFT_NAME(usercreated);
@property(nonatomic, readwrite) NSDate * dateupdated NS_SWIFT_NAME(dateupdated);
@property(nonatomic, readwrite) NSString * userupdated NS_SWIFT_NAME(userupdated);
@property(nonatomic, readwrite) GXObjectCollection * attributes NS_SWIFT_NAME(attributes);

- (genexussecurity_SdtGAMUser *)get NS_SWIFT_NAME(get());
- (NSString *)getid NS_SWIFT_NAME(getid());
- (NSString *)getlogin NS_SWIFT_NAME(getlogin());
- (NSString *)getname NS_SWIFT_NAME(getname());
- (NSString *)getexternalid NS_SWIFT_NAME(getexternalid());
- (NSString *)getemail NS_SWIFT_NAME(getemail());
- (BOOL)isanonymous NS_SWIFT_NAME(isanonymous());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOGAMUserData)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOGAMUserData> gxEOClass_GXEOGAMUserData;

@end

NS_ASSUME_NONNULL_END
