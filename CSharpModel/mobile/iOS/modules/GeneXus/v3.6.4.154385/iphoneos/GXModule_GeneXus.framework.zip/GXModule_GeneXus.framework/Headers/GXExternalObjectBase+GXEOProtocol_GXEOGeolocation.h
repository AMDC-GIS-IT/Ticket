@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@class genexus_common_SdtGeolocationInfo;
@class genexus_common_SdtGeolocationProximityAlert;

@protocol GXEOProtocol_GXEOGeolocation <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSInteger authorizationStatusNumber NS_SWIFT_NAME(authorizationStatusNumber);

+ (genexus_common_SdtGeolocationInfo *)getmylocation:(NSInteger)minAccuracy :(NSInteger)timeout :(BOOL)includeHeadingAndSpeed :(BOOL)ignoreErrors  NS_SWIFT_NAME(getmylocation(_:_:_:_:));
+ (genexus_common_SdtGeolocationInfo *)getmylocation:(NSInteger)minAccuracy :(NSInteger)timeout :(BOOL)includeHeadingAndSpeed  NS_SWIFT_NAME(getmylocation(_:_:_:));
+ (BOOL)locationservicesauthorized NS_SWIFT_NAME(locationservicesauthorized());
+ (BOOL)locationservicesenabled NS_SWIFT_NAME(locationservicesenabled());
+ (NSDecimal)getlatitude:(NSString *)location  NS_SWIFT_NAME(getlatitude(_:));
+ (NSDecimal)getlongitude:(NSString *)location  NS_SWIFT_NAME(getlongitude(_:));
+ (NSInteger)getdistance:(NSString *)fromLocation :(NSString *)toLocation  NS_SWIFT_NAME(getdistance(_:_:));
+ (GXObjectCollection *)getaddress:(NSString *)location  NS_SWIFT_NAME(getaddress(_:));
+ (GXObjectCollection *)getlocation:(NSString *)address  NS_SWIFT_NAME(getlocation(_:));
+ (BOOL)setproximityalerts:(GXObjectCollection *)proximityAlerts  NS_SWIFT_NAME(setproximityalerts(_:));
+ (GXObjectCollection *)getproximityalerts NS_SWIFT_NAME(getproximityalerts());
+ (genexus_common_SdtGeolocationProximityAlert *)getcurrentproximityalert NS_SWIFT_NAME(getcurrentproximityalert());
+ (void)clearproximityalerts NS_SWIFT_NAME(clearproximityalerts());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOGeolocation)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOGeolocation> gxEOClass_GXEOGeolocation;

@end

NS_ASSUME_NONNULL_END
