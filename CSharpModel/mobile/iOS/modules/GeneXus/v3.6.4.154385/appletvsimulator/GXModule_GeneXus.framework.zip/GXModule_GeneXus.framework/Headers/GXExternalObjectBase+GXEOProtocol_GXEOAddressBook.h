@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOAddressBook <NSObject>

- (instancetype)init;

+ (GXObjectCollection *)getAllContacts NS_SWIFT_NAME(getAllContacts());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOAddressBook)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOAddressBook> gxEOClass_GXEOAddressBook;

@end

NS_ASSUME_NONNULL_END
