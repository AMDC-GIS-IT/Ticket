@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOClientStorageAPI <NSObject>

- (instancetype)init;

+ (void)set:(NSString *)key :(NSString *)value  NS_SWIFT_NAME(set(_:_:));
+ (void)secureSet:(NSString *)key :(NSString *)value  NS_SWIFT_NAME(secureSet(_:_:));
+ (NSString *)get:(NSString *)key  NS_SWIFT_NAME(get(_:));
+ (void)remove:(NSString *)key  NS_SWIFT_NAME(remove(_:));
+ (void)clear NS_SWIFT_NAME(clear());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOClientStorageAPI)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOClientStorageAPI> gxEOClass_GXEOClientStorageAPI;

@end

NS_ASSUME_NONNULL_END
