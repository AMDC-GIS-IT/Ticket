@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEONetworkAPI <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSString * applicationserverurl NS_SWIFT_NAME(applicationserverurl);

+ (BOOL)isserveravailable NS_SWIFT_NAME(isserveravailable());
+ (BOOL)isserveravailable:(NSString *)Url  NS_SWIFT_NAME(isserveravailable(_:));
+ (NSInteger)connectiontype NS_SWIFT_NAME(connectiontype());
+ (NSInteger)connectiontype:(NSString *)Url  NS_SWIFT_NAME(connectiontype(_:));
+ (BOOL)trafficbasedcost NS_SWIFT_NAME(trafficbasedcost());
+ (BOOL)trafficbasedcost:(NSString *)Url  NS_SWIFT_NAME(trafficbasedcost(_:));
+ (void)setApplicationServerURL:(NSString *)Url  NS_SWIFT_NAME(setApplicationServerURL(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEONetworkAPI)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEONetworkAPI> gxEOClass_GXEONetworkAPI;

@end

NS_ASSUME_NONNULL_END
