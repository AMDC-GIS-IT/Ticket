@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOiOSPermissions <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSInteger userTrackingPermissionStatusNumber NS_SWIFT_NAME(userTrackingPermissionStatusNumber);

+ (void)requestUserNotificationsPermission NS_SWIFT_NAME(requestUserNotificationsPermission());
+ (void)requestLocationPermissionWhenInUse NS_SWIFT_NAME(requestLocationPermissionWhenInUse());
+ (void)requestLocationPermissionAlways NS_SWIFT_NAME(requestLocationPermissionAlways());
+ (void)requestRemoteNotificationsPermission NS_SWIFT_NAME(requestRemoteNotificationsPermission());
+ (void)requestUserTrackingPermission NS_SWIFT_NAME(requestUserTrackingPermission());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOiOSPermissions)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOiOSPermissions> gxEOClass_GXEOiOSPermissions;

@end

NS_ASSUME_NONNULL_END
