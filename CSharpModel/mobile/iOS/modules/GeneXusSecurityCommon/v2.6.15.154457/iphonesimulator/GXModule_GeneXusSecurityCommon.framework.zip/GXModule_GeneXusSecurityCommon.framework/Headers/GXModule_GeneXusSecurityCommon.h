//
//  GXModule_GeneXusSecurityCommon.h
//  GXModule_GeneXusSecurityCommon
//

#import <UIKit/UIKit.h>

//! Project version number for GXModule_GeneXusSecurityCommon.
FOUNDATION_EXPORT double GXModule_GeneXusSecurityCommonVersionNumber;

//! Project version string for GXModule_GeneXusSecurityCommon.
FOUNDATION_EXPORT const unsigned char GXModule_GeneXusSecurityCommonVersionString[];

#import <GXModule_GeneXusSecurityCommon/GXGlobalImports.h>

