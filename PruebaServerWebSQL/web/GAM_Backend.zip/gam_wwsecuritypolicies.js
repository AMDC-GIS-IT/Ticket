/*
               File: GAM_WWSecurityPolicies
        Description: Security policies
             Author: GeneXus C# Generator version 17_0_6-154974
       Generated on: 10/29/2021 0:25:29.61
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwsecuritypolicies', false, function () {
   this.ServerClass =  "gam_wwsecuritypolicies" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwsecuritypolicies.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e15082_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_securitypolicyentry.aspx", ["DSP", this.AV10Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e11082_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e13082_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e14082_client=function()
   {
      /* Btnsaveas_Click Routine */
      return this.executeServerEvent("VBTNSAVEAS.CLICK", true, arguments[0], false, false);
   };
   this.e16082_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e17082_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,24,25,26,27];
   this.GXLastCtrlId =27;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",23,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwsecuritypolicies",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",24,"vNAME",gx.getMessage( "Name"),"","Name","char",0,"px",254,80,"left","e15082_client",[],"Name","Name",true,0,false,false,"Attribute TextLikeLink SmallLink",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",25,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e13082_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btnsaveas",26,"vBTNSAVEAS","","","BtnSaveAs","char",0,"px",20,20,"left","e14082_client",[],"Btnsaveas","BtnSaveAs",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",27,"vID",gx.getMessage( "Key Numeric Long"),"","Id","int",0,"px",12,12,"right",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLETOP",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"ADDNEW1",grid:0,evt:"e11082_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",gxz:"ZV14Search",gxold:"OV14Search",gxvar:"AV14Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV14Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLE1",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV12Name",gxold:"OV12Name",gxvar:"AV12Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV12Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e15082_client"};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e13082_client"};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNSAVEAS",gxz:"ZV5BtnSaveAs",gxold:"OV5BtnSaveAs",gxvar:"AV5BtnSaveAs",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnSaveAs=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnSaveAs=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNSAVEAS",row || gx.fn.currentGridRowImpl(23),gx.O.AV5BtnSaveAs,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnSaveAs=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNSAVEAS",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e14082_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV10Id",gxold:"OV10Id",gxvar:"AV10Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'number',v2v:function(Value){if(Value!==undefined)gx.O.AV10Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(23),gx.O.AV10Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(23),gx.thousandSeparator)},nac:gx.falseFn};
   this.AV14Search = "" ;
   this.ZV14Search = "" ;
   this.OV14Search = "" ;
   this.ZV12Name = "" ;
   this.OV12Name = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.ZV5BtnSaveAs = "" ;
   this.OV5BtnSaveAs = "" ;
   this.ZV10Id = 0 ;
   this.OV10Id = 0 ;
   this.AV14Search = "" ;
   this.AV12Name = "" ;
   this.AV6BtnUpd = "" ;
   this.AV5BtnSaveAs = "" ;
   this.AV10Id = 0 ;
   this.Events = {"e11082_client": ["'ADDNEW'", true] ,"e13082_client": ["VBTNUPD.CLICK", true] ,"e14082_client": ["VBTNSAVEAS.CLICK", true] ,"e16082_client": ["ENTER", true] ,"e17082_client": ["CANCEL", true] ,"e15082_client": ["VNAME.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV14Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV14Search',fld:'vSEARCH',pic:''}],[{av:'AV6BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV5BtnSaveAs',fld:'vBTNSAVEAS',pic:''},{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV12Name',fld:'vNAME',pic:''}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV14Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV14Search',fld:'vSEARCH',pic:''},{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNSAVEAS.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV14Search',fld:'vSEARCH',pic:''},{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[]];
   GridwwContainer.addRefreshingVar(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[14]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwsecuritypolicies);});
